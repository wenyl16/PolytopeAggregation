# -*- coding: utf-8 -*-
"""
P3-1: CAISO 交易日块张量 —— 按 OPR_DT/OPR_HR 原生组织 (交易日, 24, N)
处理: OPR_HR ∈ 1..24 正常; 春季 23h 日 HE3 缺 → NaN 并记录; 秋季 25h 日 OPR_HR=25
      → 截断到 24 并记录(重复的 HE2 取第一个, 与 OASIS 惯例一致)。
同时输出 MISO 日块视图校验(原生 1277×24 直接 reshape, 无需重建)。
落盘: data/tensors/caiso_dayblocks.npz  (lmp, mcc: D×24×N float32; days: D; 备注 json)
"""
import os, glob, json, time
import numpy as np
import pandas as pd
import pyarrow.parquet as pq

RAW = r"D:/workspace/energy_data/raw/caiso/lmp"
TEN = r"D:/workspace/paper4/data/tensors"
t0 = time.time()

core = open(os.path.join(TEN, "caiso_nodes.txt")).read().split("\n")
core_idx = {n: j for j, n in enumerate(core)}
N = len(core)
files = sorted(glob.glob(os.path.join(RAW, "caiso_lmp_dam_all_*.parquet")))
D = len(files)
X_lmp = np.full((D, 24, N), np.nan, dtype=np.float32)
X_mcc = np.full((D, 24, N), np.nan, dtype=np.float32)
days = np.empty(D, dtype="datetime64[D]")
anomalies = []

for i, f in enumerate(files):
    day = os.path.basename(f)[-16:-8]
    days[i] = np.datetime64(f"{day[:4]}-{day[4:6]}-{day[6:]}")
    tbl = pq.read_table(f, columns=["OPR_DT", "OPR_HR", "NODE", "LMP_TYPE", "MW"])
    df = tbl.to_pandas()
    df = df[df["LMP_TYPE"].isin(("LMP", "MCC")) & df["NODE"].isin(core_idx)]
    hrs = df["OPR_HR"].values.astype(int)
    if hrs.max() > 24:
        anomalies.append((day, "25h_truncated"))
        df = df[hrs <= 24]
        hrs = df["OPR_HR"].values.astype(int)
    present = np.unique(hrs)
    if len(present) < 24:
        anomalies.append((day, f"23h_missing_HE{sorted(set(range(1,25))-set(present))}"))
    df = df.drop_duplicates(subset=["OPR_HR", "NODE", "LMP_TYPE"], keep="first")
    hh = df["OPR_HR"].values.astype(int) - 1
    cc = df["NODE"].map(core_idx).values
    mw = df["MW"].values.astype(np.float32)
    is_l = (df["LMP_TYPE"] == "LMP").values
    X_lmp[i, hh[is_l], cc[is_l]] = mw[is_l]
    X_mcc[i, hh[~is_l], cc[~is_l]] = mw[~is_l]
    if (i + 1) % 200 == 0:
        print(f"[day] {i+1}/{D} {time.time()-t0:.0f}s", flush=True)

np.savez_compressed(os.path.join(TEN, "caiso_dayblocks.npz"),
                    lmp=X_lmp, mcc=X_mcc, days=days.astype("int64"))
with open(os.path.join(TEN, "caiso_dayblocks_log.json"), "w") as fh:
    json.dump({"anomalies": anomalies, "shape": list(X_lmp.shape),
               "nan_lmp": float(np.isnan(X_lmp).mean())}, fh, indent=2, default=str)
print(f"[p3_day] DONE {time.time()-t0:.0f}s shape={X_lmp.shape} "
      f"nan={np.isnan(X_lmp).mean():.4%} anomalies={len(anomalies)}", flush=True)

# MISO 校验: 原生日块 = miso_da_lmp reshape(1277,24,N), 首末日与 time 轴一致即可
mt = np.load(os.path.join(TEN, "miso_time_utc.npy"))
assert len(mt) % 24 == 0
md = mt.reshape(-1, 24)
ok = bool(((md[:, 0] + np.timedelta64(23, "h")) == md[:, 23]).all())
print(f"[miso] native dayblocks check: contiguous 24h per block = {ok}", flush=True)
