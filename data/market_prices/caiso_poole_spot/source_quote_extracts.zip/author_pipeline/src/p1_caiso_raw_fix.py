# -*- coding: utf-8 -*-
"""
P1-3b: 重建原始(未插补) caiso_da_lmp / caiso_da_mcc 张量, 覆盖 canonical 版本。
背景: spike01/02 为建模方便对张量做了列均值插补后落盘, 复制到 data/tensors 后
      NaN 信息丢失。正式管线规范: 张量保留原始 NaN, 插补/剔除由 missing_flags 驱动。
spike 的 results/spike01/X_*.npy 保持不动(spike 复现依赖)。
"""
import os, glob, time
import numpy as np
import pandas as pd
import pyarrow.parquet as pq

RAW = r"D:/workspace/energy_data/raw/caiso/lmp"
TEN = r"D:/workspace/paper4/data/tensors"
t0 = time.time()

row_time = np.load(os.path.join(TEN, "caiso_time_utc.npy"))
core = open(os.path.join(TEN, "caiso_nodes.txt")).read().split("\n")
core_idx = {n: j for j, n in enumerate(core)}
tmap = {t: i for i, t in enumerate(row_time)}
T, N = len(row_time), len(core)

COMPS = ("LMP", "MCC")
Xs = {c: np.full((T, N), np.nan, dtype=np.float32) for c in COMPS}
files = sorted(glob.glob(os.path.join(RAW, "caiso_lmp_dam_all_*.parquet")))
for i, f in enumerate(files):
    tbl = pq.read_table(f, columns=["INTERVALSTARTTIME_GMT", "NODE", "LMP_TYPE", "MW"])
    df = tbl.to_pandas()
    df = df[df["LMP_TYPE"].isin(COMPS) & df["NODE"].isin(core_idx)]
    ts = pd.to_datetime(df["INTERVALSTARTTIME_GMT"].str[:13], format="%Y-%m-%dT%H").values.astype("datetime64[h]")
    rr = np.array([tmap.get(t, -1) for t in ts])
    cc = df["NODE"].map(core_idx).values
    for c in COMPS:
        m = (df["LMP_TYPE"] == c).values & (rr >= 0)
        Xs[c][rr[m], cc[m]] = df["MW"].values[m].astype(np.float32)
    if (i + 1) % 200 == 0:
        print(f"[rawfix] {i+1}/{len(files)} {time.time()-t0:.0f}s", flush=True)

for c in COMPS:
    np.save(os.path.join(TEN, f"caiso_da_{c.lower()}.npy"), Xs[c])
    print(f"[rawfix] caiso_da_{c.lower()} saved nan={np.isnan(Xs[c]).mean():.4%}", flush=True)
print(f"[rawfix] DONE {time.time()-t0:.0f}s", flush=True)
