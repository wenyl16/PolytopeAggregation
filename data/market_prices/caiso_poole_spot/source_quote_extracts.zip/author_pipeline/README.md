# CBD: Nodal electricity price field tensors and forecasting pipeline (CAISO / MISO / NYISO, 2023–2026)

Companion data-and-code deposit for the manuscript *"Topology-free probabilistic
forecasting of full nodal electricity price fields via congestion-basis
decomposition"* (submitted to Sustainable Energy, Grids and Networks).

All raw data originate from public sources: CAISO OASIS API, MISO public market
reports, NYISO public CSV archives, and the U.S. EIA-930 API. This deposit
contains the derived tidy datasets and the complete experiment pipeline.

## Archive contents

| Archive | Contents |
|---|---|
| `cbd_tensors_caiso.zip` | CAISO canonical hourly tensors (UTC axis), plus the cross-market `missing_flags.parquet`; see data dictionary below |
| `cbd_tensors_miso_da.zip` | MISO day-ahead tensors plus shared MISO metadata (time axis, node master, covariate) |
| `cbd_tensors_miso_rt.zip` | MISO real-time ex-post tensors (LMP, MCC, MLC) |
| `cbd_nyiso_processed.zip` | NYISO tidy parquet tables (5 series types, 2020–2025, UTC) |
| `cbd_results.zip` | Frozen test results, baseline-family comparisons, probabilistic references, DM tests (JSON + per-node daily-loss NPZ; see RESULTS_GUIDE.md inside) |
| `cbd_code.zip` | Full pipeline source (`src/`), method package (`src/cbd/`), frozen protocol document (`D0-definitions.md`), this README |

## Data dictionary (cbd_tensors.zip)

| File | Shape / type | Description |
|---|---|---|
| `caiso_da_{lmp,mce,mcc,mcl,mghg}.npy` | (hours × 1926) float32 | CAISO day-ahead LMP and its four published components; NaN = missing (0.09%) |
| `caiso_dayblocks.npz` | lmp/mcc (days × 24 × 1926), days | CAISO trading-day blocks (OPR_DT, Pacific prevailing time; DST days logged) |
| `caiso_time_utc.npy`, `caiso_nodes.txt` | — | Hour axis (UTC) and node identifiers |
| `caiso_cov_loadfcst.npy`, `caiso_cov_dayblocks.npy` | (hours,), (days × 24) | CAISO official day-ahead system load forecast covariate |
| `miso_{da,rt}_{lmp,mcc,mlc}.npy` | (30648 h × 2165) float32 | MISO day-ahead / real-time ex-post LMP and components (EST market, UTC axis) |
| `miso_time_utc.npy`, `miso_nodes.txt`, `miso_node_master.parquet` | — | Time axis, node list, node master table |
| `miso_cov_loadfcst.npy` | (hours,) | EIA-930 day-ahead demand forecast covariate |
| `missing_flags.parquet` | 3,661 rows | All missing node-days, classified (all `drop_node_day`; no interpolation) |
| `*_log.md` / `*_log.json` | — | Parse and QC logs |

## Reproduction

Environment: Python 3.10, NumPy 1.26, LightGBM 4.7, pandas, pyarrow
(deep baselines additionally: PyTorch 2.x, chronos-forecasting).

Pipeline order (all under `src/`):
1. `p1_*.py` — raw → tensors (already materialized in this deposit)
2. `p2_validation_{caiso,miso}.py`, `p2_prob_routes.py` — validation-window selection
3. `p3_caiso_day_tensor.py`, `p3_run.py` — frozen test period (run once), `p3_run_amend2.py`, `p3_amend1_zombie_filter.py` — labelled amendments
4. `p3_nyiso_control.py`, `p3_dart.py` — control and economic backtest
5. `a30_*.py` — deep/foundation-model baselines (GPU)
6. `p4_*.py` — merges, probabilistic reference, CRPS DM tests, figures

The frozen evaluation protocol (D0) is included as `D0-definitions.md`.

## Licenses

- **Data** (tensors, parquet, results): CC BY 4.0
- **Code** (`cbd_code.zip`): MIT License

Underlying raw market data remain subject to the respective ISO/EIA terms of
use; they are public and were accessed via documented public interfaces.

## Citation

Zhang, J., Zhang, H., Shen, L., & Xu, Z. (2026). CBD: Nodal electricity price
field tensors and forecasting pipeline (CAISO/MISO/NYISO, 2023–2026) [Data set].
Zenodo. https://doi.org/10.5281/zenodo.21522100
