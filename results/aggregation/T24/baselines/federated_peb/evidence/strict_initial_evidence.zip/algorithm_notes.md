# Federated PEB：原论文流程与严格执行诊断

依据本地论文 *Federated Aggregation of Polyhedral Demand Flexibility Sets*，Dong、Chen、Qin，IEEE Transactions on Smart Grid，2026。页码指 PDF 第 1–14 页。论文 SHA256：`5832deb9f83c0cca8ed8b3a9c4b354ba27b0fe91d5529af07475298a9e031b41`。

这里记录严格流程的诊断，不把未完成的基集合优化记为训练成功。旧方案的近最优 trace 约束、L1 次目标和选定 simplex 基导数不属于这里要求的严格论文复现，不能继续作为论文方法的有效结果参与对比。

## 场景与原始局部问题

采用 `Simulator.cases.aggregation_case_T24.Aggregator`，场景种子 0，`counts=(5,40,5)`，即 CL 5、连续 TCL 40、PV 5，T=24、deltaT=1 小时。每个设备使用真实的 `Ui={q:Ai*q<=bi}`。TCL 按实际模型消去温度，保留 t=1,...,23 的所有温度界；t=0 温度固定，其功率不进入温度递推。没有用近似累计能量包络替代真实热动态。异构 Ai 的使用依据第 4 页 Lemma 1 式(9)和第 6 页 IV-E。

严格保留第 3 页式(3)、第 4 页式(5)的完整 PEB 参数：

```text
L = deltaT * tril(ones(T,T))
H0 = [L; -L; I; -I]                         # 96 × 24
h  = [energy_upper; -energy_lower;
      power_upper;  -power_lower]           # 96 个 RHS 坐标
U0(h) = {u : H0*u <= h}
```

不删首时刻重复的能量/功率行，不做行平均归一化。按第 8 页 VI-A(2)使用 `h=ones(96)` 初始化。式(14)的 epsilon 为 `1e-5`，与第 7 页案例设置一致。

每个设备每次只解第 4 页式(12)的一个原始 LP：

```text
max trace(Gamma_i)
s.t. Lambda_i >= 0
     Lambda_i*H0 = Ai*Gamma_i
     Lambda_i*h + Ai*gamma_i <= bi
```

Gamma 是完整 24×24 自由矩阵，gamma 自由，Lambda 非负。没有 L1、最小范数或正则化次目标，没有 `trace=optimum-tolerance` 或其他 trace 平移，也不限制 Gamma 为标量、对角或正定矩阵。求解容差仅用于数值求解与残差核验。

## 投影、目标与附录 B 完整 KKT

第 5 页式(14)最小化 `||h-h_tilde||²`，约束 `H0*u+epsilon<=h_tilde`。若 u=0 已严格可行，零距离投影可以解析返回原 h 和单位 Jacobian；一般情况求解相同的 QP 并核验原始/对偶残差和导数条件。

第 4–5 页式(13)、(15)–(19)的目标为：

```text
s = sum(gamma_i)
S = sum(Gamma_i)
J(h) = abs(det(S)) * volume(U0(h_tilde(h)))
```

数值上可存储 log J 避免溢出，但回溯接受条件对应原 J 的 Armijo 上升条件。用 log 比值实现同一不等式，不替换为直接对 log J 应用的另一条 Armijo 条件。

局部导数使用第 11 页附录 B 式(36)–(38)的完整原始/对偶 KKT 系统。令 `g=Lambda*h+Ai*gamma-bi`，变量为 `(gamma,Gamma,Lambda,Y,mu,nu)`，残差包括：

```text
Ai.T*mu
-I - Ai.T*Y
Y*H0.T + mu*h.T - nu
Lambda*H0 - Ai*Gamma
mu .* g
nu .* Lambda
```

直接组装完整 Jacobian Jz。代码 row-major 存储仅同时置换论文 column-major 系统的行、列。对 Gamma 上游权重 W，解完整转置方程 `Jz.T*a=[0;vec(W);0;0;0;0]`。a3、a5 对应第三、第五残差块时：

```text
VJP(W) = -a3.T*mu - Lambda.T*(mu .* a5)
```

不使用伪逆、ridge、删弱互补行或选定 LP basis 的导数替代式(38)。完整系统结构奇异、数值奇异、弱互补或残差不合格时记录 `KKTRegularityError`，停止基集合优化；不以额外目标、替代算法或人为有限梯度继续。

第 5 页 IV-C 采用 KKT 和隐函数定理，第 11 页式(38)直接使用 `Jz^{-1}`，但原文没有给出退化点、非唯一解选择或奇异系统的替代规则。完整系统不可逆只表明这一原文求导路径在该点不能执行；不证明所有表示下的 Gamma 导数均不存在，也不等于设备 LP 不可行。

## 回溯与 Algorithm 1

第 8 页 VI-A(2)明确使用 **standard backtracking line search**，保证目标单调上升。原文没有指定初始步长、缩减比例、Armijo 常数、最大回溯数、梯度阈值或秒数预算，不能将本地配置称为论文原参数。全文只有第 12 页的 **Algorithm 1：Numerical Recursive Integration**，没有 Algorithm 2；外层流程见第 5 页 Fig.2。

体积按附录 C、D 式(39)–(46)及 Algorithm 1，以一个共同固定 delta_x 进行 Riemann 递推。第 t 层状态区间为式(44)的能量界与累计功率界交集；前向递推对上一层节点的闭区间 indicator 求和并乘 delta_x，最后再乘 delta_x 求总体积。前缀和仅加速相同有限求和，不替换成插值 CDF 或梯形规则。RHS 导数按附录 C 的 Leibniz/Dirac 边界式，先解析消去 Dirac 项，再对剩余维度使用相同 Riemann 求和；首时刻按 Dirac 初态处理。

累计状态积分除以 `deltaT**T` 后转换为功率空间体积。本例 deltaT=1。网格原点、共同 delta_x、节点数、余下不足一格的区间宽度和闭端点约定均需明示，不能称为论文已指定的数值。Algorithm 1 的(47)/(48)引用实际对应式(45)/(46)；式(44)累计和中的功率按各时刻求和。

完整 96 参数在全 1 初始化时，首能量界与首功率界重合。体积例程报告这些重合面；不能据单独的边界贡献宣称存在唯一经典 RHS 梯度，也不能通过删参数、任意分摊或半端点替换隐去这一限制。

## 已核对的严格初始轮

独立核对 `strict_paper_initial_round.json` 的全部 50 条设备记录：

| 项目 | 结果 |
| --- | ---: |
| 原始 LP 最优且通过包含证书 | 50 / 50 |
| 聚合 S 的秩 | 24 |
| S 条件数 | 11034.411243626964 |
| S 最小奇异值 | 0.06519846112857512 |
| 完整 KKT Jacobian 结构奇异 | 50 / 50 |
| 可按式(38)计算的导数 | 0 / 50 |
| 最大原始/对偶 KKT 残差 | 2.3447910280083306e-13 |
| 最大主问题原始/对偶目标差绝对值 | 5.684341886080802e-14 |
| 独立初始轮总耗时 | 16.776607000036165 秒 |
| 求解器累计耗时 | 14.869000434875488 秒 |

初始仿射包含问题已求解成功，但论文完整 KKT 逆不能用于本场景的第一次参数更新。上述是独立初始轮的诊断数据，不是已训练模型或误差/成本测试结果。

正式严格入口的 `training_diagnostics.json` 状态为 `unsupported_paper_regularity`，停止原因为 `paper_derivative_or_inverse_undefined`。在 200 秒上限内实际执行 15.211468000081368 秒，纯模型准备另计 0.6792049999348819 秒；完成 1 个初始候选、50 次原始局部 LP，完成梯度轮数为 0、接受参数更新数为 0。第一个设备 `cl_000` 的完整 KKT 为 11016 阶，结构秩 9690，存在 1326 个严格零 Jacobian 行，KKT 残差仅 1.7763568394002505e-15；小残差没有消除结构奇异性。独立的 `paper_fidelity_check.json` 进一步确认全部 50 个设备均存在同类障碍。正式入口没有把初始可行点发布为完成训练的模型，`provenance.json` 的评估状态为 `not_run_no_valid_trained_model`。

这一场景还存在不依赖数值求解的 CL 非唯一性反例。在 deltaT=1、h=ones 时，base 同时满足 `|u_t|<=1` 和 `|sum(u_1,...,u_t)|<=1`。真实 CL 的功率域为 box，记中心为 c、半宽为 r>0。由于正负单位向量均在 base 内，任何可行变换都有 `Gamma_tt<=r_t`，故最大 trace 不超过 `sum(r)`。`gamma=c, Gamma=diag(r)` 达到该上界。任选 t>1，把 Gamma 的第 t 行由 `r_t*e_t.T` 改成 `r_t*L_t`，仍因累计界而落在同一 CL box 内，对角项和 trace 不变，但 Gamma 已不同；两者的所有凸组合也可行且最优。因此本次五个 CL 的原始 LP 至少具有连续的 Gamma 最优面。原问题本身没有指定唯一 Gamma 选择函数，不能由“已最优”或“小 KKT 残差”推出唯一经典导数；这不排除另行定义某个选解函数，但论文未给出该规则。

## 200 秒预算与失败产物

200 秒是本地比较的最大训练预算，不是论文规定的迭代数；公式已无法执行时不空耗满预算。物理场景生成和纯模型装配另列准备时间；训练时钟从第一次投影/原始 LP 前开始，计入初始轮、局部 LP、完整 KKT、积分、回溯和被拒候选。独立复核及下游评估另计。

若原式(38)或式(19)所需逆不存在，严格入口返回明确失败诊断，保存必要证据；不伪造更新，不把全 1 初始点冒充训练完成，不回退旧 L1 结果，也不以零值或其他方法数据填补误差/成本。

旧方案包含 94 行参数、近最优 trace target、min-L1 次目标及选定 simplex basis 灵敏度。即使其局部包含证书成立，也不能视为本次要求的原论文复现。该旧方法的活跃最终模型、误差/成本条目和第十条曲线已从汇总撤回，两份 summary PDF 同步恢复原九方法。43 个受保护输入的 SHA256 核验通过；撤回记录、初始证书和失败诊断不算成功测试。

单机执行是客户端/聚合器算术的顺序模拟，没有部署 secure summation 或真实多机通信，不宣称部署级隐私性能。原九方法数据、5000 个 seed=1 评估方向和 365 天 AEMO VIC1 电价保持既有含义；严格失败时不发布该方法的有效评估曲线。
